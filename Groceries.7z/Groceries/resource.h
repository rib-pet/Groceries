//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Groceries.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_DELETE_ERROR                101
#define IDR_MAINFRAME                   128
#define ID_NEW_GROUP                    129
#define ID_NEW_SUB_GROUP                130
#define ID_NEW_ITEM                     131
#define ID_PROPETY                      132
#define IDR_GroceriesTYPE               200
#define IDD_GRO_DLG                     310
#define IDD_STAT_DLG                    311
#define IDB_GROS                        315
#define IDR_TOOLBAR1                    320
#define IDD_STATIONERY_DLG              321
#define IDD_GRO_BASIC_PAGE              323
#define IDD_STUFF_DLG                   324
#define IDR_STATIONERY                  325
#define IDC_GRO_TREE                    1000
#define IDC_STATIONERY_LIST             1001
#define IDC_KEY                         1002
#define IDC_DESC                        1003
#define IDC_STUFF_LIST                  1003
#define IDC_EDIT_ID                     1005
#define IDC_EDIT_NAME                   1006
#define IDC_EDIT_DESC                   1007
#define IDC_EDIT_UP                     1008
#define IDC_EDIT_QTY                    1009
#define IDC_EDIT_COMMENT                1010
#define IDC_SAVE                        1011
#define IDC_DISCARD                     1012
#define IDS_STATIONERY_TITLE            2000
#define IDS_BASE_PAGE                   2001
#define IDS_STUFF_DETAIL                2002
#define ID_VIEW_STATINERY               32772
#define ID_REFRESH                      32773
#define ID_VIEW_PROPERTY                32775
#define ID_DELETE                       32776
#define ID_VIEW_STUFFDETAILS            32780
#define ID_STATIONERY_APPEND            32781
#define ID_STATIONERY_DELETE            32782
#define ID_ACTION_IMPORTSTATIONERY      32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        330
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           312
#endif
#endif
