#include "stdafx.h"
#include "Stuff.h"


Stuff::Stuff(void)
{
}


Stuff::~Stuff(void)
{
}
