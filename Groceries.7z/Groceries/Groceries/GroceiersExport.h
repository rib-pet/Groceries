#ifndef _PDC_GROCEIERSEXPORT_H
#define _PDC_GROCEIERSEXPORT_H
#pragma once

#include "PDCCore.h"
#include "afx.h"

class PDC_CLASS_DECL GroceriesExportWrapper 
{
public: 
	GroceriesExportWrapper();
	~GroceriesExportWrapper();

protected:
	class GroceriesExport;
	GroceriesExport* m_pExport;
};


#endif // !_PDC_GROCEIERSEXPORT_H
