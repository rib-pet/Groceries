#ifndef _PDC_GROCERIESGROUP_H_
#define _PDC_GROCERIESGROUP_H_


#pragma once
#include "afx.h"
#include <vector>
#include <list>
#include "PDCCore.h"

// forward declaration
class GroceriesVisitor;
class GroceriesItem;

class PDC_CLASS_DECL GroceriesGroup : public CObject
{
	DECLARE_SERIAL(GroceriesGroup)
public:
	GroceriesGroup(void);
	GroceriesGroup(CObject* Parent);
	GroceriesGroup(BYTE* pBytes,int iLength);
	virtual ~GroceriesGroup(void);

	virtual void SetName(const CString& strKey); 
	virtual CString GetName() const;
	
	virtual void SetDescription(const CString& strDesc);
	virtual CString GetDescription();

	virtual GroceriesGroup* CreateGroup();
	virtual int GetChildrenCount();
	virtual GroceriesGroup* GetGroupAt(int nIndex);
	virtual void DeleteGroup(const CString& strKey);
	virtual void RemoveAllGroups();


	virtual GroceriesItem* CreateItem();
	virtual int GetItemCount();
	virtual GroceriesItem* GetItemAt(int nIndex);
	virtual void DeleteItem(const CString& strKey);
	virtual void RemoveAllItems();

	virtual void Accept( GroceriesVisitor* pVisitor );
	virtual void GetChildren( std::list<CObject*>& rgpChildren );

	virtual void SetParentObject(CObject* pParent);
	virtual CObject* GetParentObject();

	virtual void Delete();
	virtual void Remove(CObject* pChild);

	virtual void Serialize(CArchive& ar);

	void FromBytes(BYTE* pBytes,int iLength);
	BYTE* GetBytes(int& iLength);
protected:
	//
	//! name
	// 
	CString m_strName;

	//
	// Description
	// 
	CString m_strDescription;

	//
	// ! it stores all Groceries
	// 
	std::vector<GroceriesGroup*> m_rgpChildren;

	//
	//! it stores all items
	// 
	std::vector<GroceriesItem*> m_rgpItems;
	//
	//!
	// 
	CObject* m_pParent;

	bool m_bFromBytes;
};

#endif // _PDC_GROCERIESGROUP_H_
