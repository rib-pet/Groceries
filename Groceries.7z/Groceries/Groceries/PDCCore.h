#ifndef __PDC_PDCCORE_H__

#define __PDC_PDCCORE_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#ifdef _PDCDLL

#define PDC_CLASS_DECL        __declspec( dllexport )
#define PDC_API_DECL          __declspec( dllexport )

#else

#define PDC_CLASS_DECL        __declspec( dllimport )
#define PDC_API_DECL          __declspec( dllimport )

#pragma comment(lib,"Pdc.lib")

#endif  //!_PDCDLL

#endif  //!__PDC_PDCCORE_H__
