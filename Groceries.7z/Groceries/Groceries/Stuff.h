#ifndef _PDC_STUFF_H_
#define _PDC_STUFF_H_

#pragma once
#include "afx.h"
#include "PDCCore.h"

class Stationery;
class GroceriesVisitor;

class PDC_CLASS_DECL Stuff : public CObject
{
	DECLARE_SERIAL(Stuff)
public:
	Stuff(void);
	Stuff(BYTE* pBytes,int iLength);
	virtual ~Stuff(void);

	//override methods
	virtual void Accept( GroceriesVisitor* pVisitor );
	virtual CString GetName();
	virtual void SetName(const CString& strName);

	virtual void Delete();
	virtual CObject* GetParent();

	Stationery* GetStationery();
	void SetStationery(Stationery*);
	CString GetDescription();

	double GetQuantity();
	void SetQuantity(double dQuantity);

	void Serialize(CArchive& ar);
	void SetDescription( CString m_strComment );

	void FromBytes(BYTE* pBytes,int iLength);
	BYTE* GetBytes(int& iLength);
protected:
	//
	//! name
	//
	CString m_strName;

	//
	// Description
	// 
	CString m_strDesription;

	//
	//! Parent object
	// 
	CObject* m_pParent;

	//
	//! stationery
	// 
	Stationery* m_pStationery;

	double m_dQuantity;

	bool m_bFromBytes;
};

#endif //_PDC_STUFF_H_

