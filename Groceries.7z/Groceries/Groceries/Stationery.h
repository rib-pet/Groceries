#pragma once
#ifndef _STATIONERY_H_
#define _STATIONERY_H_

#include "afx.h"
#include "PDCCore.h"

class PDC_CLASS_DECL Stationery : public CObject
{
	DECLARE_SERIAL(Stationery)
public:
	Stationery(void);
	Stationery(CObject* pParent);
	Stationery(BYTE* pBytes,int iLength);

	virtual ~Stationery(void);

	UINT GetID();
	void SetID(UINT nID);

	double GetUnitRate();
	void SetUnitRate(double dValue);

	double GetQuantity();
	void SetQuantity(double dQuantity);

	// Unit Rate * Quatity
	double GetCost();  

	CString GetComment();
	void SetComment(const CString& strComment);

	virtual CString GetName();
	void SetName( CString strKey );
	virtual void Delete();

	void SetDescription(const CString& strDesc);
	CString GetDescription();

	virtual void Serialize(CArchive& ar);

	void FromBytes(BYTE* pBytes,int iLength);

	BYTE* GetBytes(int& iLength);

protected:
	UINT m_nID;
	// Unit rate
	double m_dUnitPrice;

	// Quantity
	double m_dQuantity;

	// name
	CString m_strName;

	// Description
	CString m_strDescription;

	//Comment
	CString m_strComment;

	// Parent
	CObject* m_pParent;

	bool m_bFromBytes;
};

#endif // _STATIONERY_H_
