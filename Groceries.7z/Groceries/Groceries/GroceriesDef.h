#ifndef _GROCERIESDEF_H_
#define _GROCERIESDEF_H_

#define STATIONERY_LINE 50
#define STATIONERY_COL 7

#define STATIONERY_NUMBER _T("No.")
#define STATIONERY_NAME	_T("Name")
#define STATIONERY_SPEC	_T("Specification")
#define STATIONERY_UP _T("Unit Price")
#define STATIONERY_QTY _T("Quantity")
#define STATIONERY_AMT _T("Amount")
#define STATIONERY_CMT _T("Comment")


#endif //_GROCERIESDEF_H_