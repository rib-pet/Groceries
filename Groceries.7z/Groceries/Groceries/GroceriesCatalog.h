#ifndef _PDC_GROCERIESCATALOG_H_
#define _PDC_GROCERIESCATALOG_H_

#pragma once
#include "afx.h"
#include <vector>
#include <list>
#include "PDCCore.h"
#include "Stationery.h"

//class Stationery;
class GroceriesGroup;
class GroceriesVisitor;

class PDC_CLASS_DECL GroceriesCatalog : public CObject
{
	DECLARE_SERIAL(GroceriesCatalog)

public:
	GroceriesCatalog();
	GroceriesCatalog(CString strName, CString strDesc = _T(""));
	GroceriesCatalog(BYTE* pBytes,int iLength);
	virtual ~GroceriesCatalog(void);

	virtual GroceriesGroup* CreateGroup();
	virtual void DeleteGroup(const CString& strKey);
	virtual GroceriesGroup* GetGroupAt(int nIndex);
	virtual void RemoveAllGroups();
	virtual int GetChildrenCount();

	virtual Stationery* CreateStationery();
	virtual Stationery* GetStationeryAt(int nIndex);
	virtual int GetStationeryCount();
	virtual void DeleteStationery(const CString& strKey);
	virtual void RemoveAllStationeries();

	virtual CString GetName();
	virtual void SetName(const CString& strName);

	virtual CString GetDescription();
	virtual void SetDescription(const CString& strDesc);

	virtual void GetChildren( std::list<CObject*> &rgpChildren );
	virtual void Accept( GroceriesVisitor* pVisitor );

	virtual void Delete();
	virtual void Remove(CObject* pChild);

	virtual void Serialize(CArchive& ar);
	Stationery* FindStationeryByID( int nID );
	bool isIdExist( int nID );
	//virtual bool AddStationery(Stationery* stationery);

	void FromBytes(BYTE* pBytes,int iLength);
	BYTE* GetBytes(int& iLength);



protected:
	//
	//! name
	// 
	CString m_strName;

	//
	//! Description
	// 
	CString m_strDescription;

	//
	// ! it stores all Groceries
	// 
	std::vector<GroceriesGroup*> m_rgpChildren;

	//
	// Stationery
	// 
	std::vector<Stationery*> m_rgpStationery;

	bool m_bFromBytes;
};

#endif // _PDC_GROCERIESCATALOG_H_
