#ifndef _PDC_GROCERIESITEM_H_
#define _PDC_GROCERIESITEM_H_

#pragma once
#include "GroceriesGroup.h"
#include "PDCCore.h"

//
// Forward declaration
// 
class Stuff;
class Stationery;

class PDC_CLASS_DECL GroceriesItem : public CObject
{
	DECLARE_SERIAL(GroceriesItem)
public:
	GroceriesItem(void);
	GroceriesItem(CObject* pParent);
	GroceriesItem(BYTE* pBytes,int iLength);
	~GroceriesItem(void);
	
	virtual int GetAllStuffs( std::vector<Stuff*>& rgpStuffs );
	virtual Stuff* CreateStuff();
	virtual void RemoveAllStuffs();
	virtual void DeleteStuff( const CString& strName);


	virtual void Delete();
	virtual void Remove(CObject* pChild);
	virtual void SetName( const CString& strKey );
	virtual CString GetName();

	virtual void SetDescription(const CString& strDesc );
	virtual CString GetDescription();

	virtual void Accept( GroceriesVisitor* pVisitor );
	virtual void Serialize(CArchive& ar);
	virtual bool IsUnique( Stationery* pStationery );

	void FromBytes(BYTE* pBytes,int iLength);
	BYTE* GetBytes(int& iLength);
protected:
	//
	// it stores all stuffs
	// 
	std::vector<Stuff*> m_rgpStuffs;

	//
	//! Parent object
	// 
	CObject* m_pParent;

	//
	// Name
	// 
	CString m_strName;

	//
	//Description
	// 
	CString m_strDescription;

	bool m_bFromBytes;
};

#endif //_PDC_GROCERIESITEM_H_