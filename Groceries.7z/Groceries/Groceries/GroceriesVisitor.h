#ifndef _GROCERIESVISITOR_H_
#define _GROCERIESVISITOR_H_

#pragma once
#include <afx.h>
#include "PDCCore.h"

//Forward declaration
class GroceriesCatalog;
class GroceriesGroup;
class GroceriesItem;
class Stuff;

class PDC_CLASS_DECL GroceriesVisitor
{
public:
	virtual ~GroceriesVisitor(void);

	virtual void VisitGroceriesCatalog(GroceriesCatalog* pCatalog);
	virtual void VisitGroceriesGroup(GroceriesGroup* pGroceriesGroup);
	virtual void VisitGroceriesItem(GroceriesItem* pGroceriesItem);
	virtual void VisitStuff( Stuff* pStuff );

protected:
	GroceriesVisitor();
};

#endif //_GROCERIESVISITOR_H_