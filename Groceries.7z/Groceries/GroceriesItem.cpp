#include "stdafx.h"
#include "..\Groceries\GroceriesItem.h"


GroceriesItem::GroceriesItem(void)
{
}


GroceriesItem::~GroceriesItem(void)
{
}
