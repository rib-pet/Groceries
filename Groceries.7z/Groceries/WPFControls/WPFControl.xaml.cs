﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using System.Data;
using System.IO;



namespace WPFControls
{
    /// <summary>
    /// Interaction logic for WPFControl.xaml
    /// </summary>
    public partial class WPFControl : UserControl
    {
        public WPFControl()
        {
            InitializeComponent();
            string strDLLPath = System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
            string dir = System.IO.Directory.GetParent((System.IO.Directory.GetParent(strDLLPath).ToString())).ToString();
            String xmlpath = dir + @"\document\stationery.xml";
            DataSet ds = new DataSet();

            ds.ReadXml(xmlpath);
            //datagridview1.DataSource = ds.Tables[1];
            datagrid1.ItemsSource = ds.Tables[1].DefaultView;
        }

        
    }
}
