#include "stdafx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#include "..\Groceries\GroceriesCatalog.h"
#include "..\Groceries\GroceriesGroup.h"
#include "..\Groceries\GroceriesVisitor.h"
#include "..\Groceries\Stationery.h"
#include <string>
#include <iostream>
using namespace std;

IMPLEMENT_SERIAL(GroceriesCatalog, CObject,1)

GroceriesCatalog::GroceriesCatalog()
{
}

GroceriesCatalog::GroceriesCatalog(CString strName , CString strDesc )
	: m_strName(strName)
	, m_strDescription(strDesc)
	,m_bFromBytes(false)
{
}


GroceriesCatalog::~GroceriesCatalog(void)
{
	if (m_bFromBytes)
	{
		;
	}
}


GroceriesGroup* GroceriesCatalog::CreateGroup()
{
	GroceriesGroup* pNewObj = new GroceriesGroup(this);
	if(pNewObj)
	{
		int nSize = (int) m_rgpChildren.size();
		CString strKey;
		strKey.Format(_T("%d"), ++nSize);
		pNewObj->SetName(strKey);

		m_rgpChildren.push_back(pNewObj);
	}

	return pNewObj;
}

CString GroceriesCatalog::GetName()
{
	return m_strName;
}

void GroceriesCatalog::SetName( const CString& strName )
{
	m_strName = strName;
}

void GroceriesCatalog::DeleteGroup( const CString& strKey )
{
	/*int nCount = GetChildrenCount();
	int nIndex = -1;
	for (int i= 0; i < nCount; ++i)
	{
	GroceriesGroup* pGroup = m_rgpChildren.at(i);
	if(pGroup && pGroup->GetName().CompareNoCase(strKey) == 0)
	{
	nIndex = i;
	break;
	}
	}

	if(nIndex != -1)
	{
	m_rgpChildren.erase(m_rgpChildren.begin() + nIndex);
	}*/

	std::vector<GroceriesGroup*>::iterator iter = m_rgpChildren.begin();
	for (; iter != m_rgpChildren.end(); ++iter)
	{
		GroceriesGroup* pGroup = *iter;
		if(pGroup && pGroup->GetName().CompareNoCase(strKey) == 0)
		{
			m_rgpChildren.erase(iter);
			break;
		}
	}
}

void GroceriesCatalog::GetChildren( std::list<CObject*> &rgpChildren )
{
	rgpChildren.clear();
	rgpChildren.assign(m_rgpChildren.begin(),m_rgpChildren.end());
}

void GroceriesCatalog::Accept( GroceriesVisitor* pVisitor )
{
	if(pVisitor)
		pVisitor->VisitGroceriesCatalog(this);
}

CString GroceriesCatalog::GetDescription()
{
	return m_strDescription;
}

void GroceriesCatalog::SetDescription( const CString& strDesc )
{
	m_strDescription = strDesc;
}

void GroceriesCatalog::RemoveAllGroups()
{
	for (int i=0; i< (int) m_rgpChildren.size(); ++i)
	{
		GroceriesGroup* pGroup = m_rgpChildren.at(i);
		if(pGroup)
		{
			delete pGroup;
			pGroup = NULL;
		}
	}
}

int GroceriesCatalog::GetChildrenCount()
{
	return (int) m_rgpChildren.size();
}

GroceriesGroup* GroceriesCatalog::GetGroupAt( int nIndex )
{
	GroceriesGroup* pGroup = NULL;

	int nCount = (int)m_rgpChildren.size();

	if(nIndex >= 0 && nIndex < nCount)
	{
		pGroup = m_rgpChildren.at(nIndex);
	}

	return pGroup;
}

void GroceriesCatalog::Delete()
{
	
}

void GroceriesCatalog::Remove( CObject* pChild )
{
	if(pChild)
	{
		Stationery* pStationery = dynamic_cast<Stationery*>(pChild);
		GroceriesGroup* pGrp = dynamic_cast<GroceriesGroup*>(pChild);
		if(pGrp)
		{
			DeleteGroup(pGrp->GetName());

			delete pGrp;
			pGrp = NULL;
		}
		else if(pStationery)
		{
			CString strID;
			strID.Format(_T("%d"), pStationery->GetID());
			if(!strID.IsEmpty())
			{
				DeleteStationery(strID);
				delete pStationery;
				pStationery = NULL;
			}
		}
	}
}

Stationery* GroceriesCatalog::CreateStationery()
{
	Stationery* pNewStationery = new Stationery(this);
	if(pNewStationery)
	{
		int nSize = (int) m_rgpStationery.size();
		pNewStationery->SetID(++nSize);

		m_rgpStationery.push_back(pNewStationery);
	}

	return pNewStationery;
}

Stationery* GroceriesCatalog::GetStationeryAt( int nIndex )
{
	Stationery* pStationery = NULL;

	int nCount = (int)m_rgpStationery.size();

	if(nIndex >= 0 && nIndex < nCount)
	{
		pStationery = m_rgpStationery.at(nIndex);
	}

	return pStationery;
}

void GroceriesCatalog::DeleteStationery( const CString& strKey )
{
	std::vector<Stationery*>::iterator iter = m_rgpStationery.begin();
	for (; iter != m_rgpStationery.end(); ++iter)
	{
		Stationery* pStationery = *iter;

		CString strID;
		
		if(pStationery)
		{
			strID.Format(_T("%d"), pStationery->GetID());
			if(!strKey.IsEmpty() && strKey.CompareNoCase(strID) == 0)
			{
				m_rgpStationery.erase(iter);
				break;
			}
		}
	}
}

void GroceriesCatalog::RemoveAllStationeries()
{
	for (int i=0; i< (int) m_rgpStationery.size(); ++i)
	{
		Stationery* pStationery = m_rgpStationery.at(i);
		if(pStationery)
		{
			delete pStationery;
			pStationery = NULL;
		}
	}
}

int GroceriesCatalog::GetStationeryCount()
{
	return (int) m_rgpStationery.size();
}


void GroceriesCatalog::Serialize(CArchive& ar)
{
	__super::Serialize(ar);
	if(ar.IsStoring())
	{
// 		ar << m_strName;
// 		ar << m_strDescription;
// 
// 		int nCount = static_cast<int>(m_rgpChildren.size());
// 		ar << nCount;
// 		if(nCount > 0)
// 		{
// 			for(int i=0; i<nCount; ++i)
// 			{
// 				GroceriesGroup* pTempGroup = m_rgpChildren.at(i);
// 				if(pTempGroup)
// 					ar << pTempGroup;
// 			}
// 		}
// 		
// 		nCount = static_cast<int>(m_rgpStationery.size());
// 		ar << nCount;
// 		if( nCount > 0)
// 		{
// 			for(int i=0; i<nCount; ++i)
// 			{
// 				Stationery* pTempStationery = m_rgpStationery.at(i);
// 				if(pTempStationery)
// 					ar << pTempStationery;
// 			}
// 		}

		int length = 0;
		BYTE * pBytes = GetBytes(length);
		char buflen[32]= {0x0};
		sprintf_s(buflen,"%d",length);
		ar.Write(buflen, sizeof(buflen));
		ar.Write(pBytes, length);
	}
	else
	{
// 		ar >> m_strName;
// 		ar >> m_strDescription;
// 
// 		int nCount;
// 		ar >> nCount;
// 
// 		GroceriesGroup* pTempGroup = NULL;
// 		for(int i=0; i<nCount; ++i)
// 		{
// 			ar >> pTempGroup;
// 			if(pTempGroup)
// 				m_rgpChildren.push_back(pTempGroup);
// 		}
// 			
// 		ar >> nCount;
// 		Stationery* pTempStationery = NULL;
// 		for(int i=0; i<nCount; ++i)
// 		{
// 			ar >> pTempStationery;
// 			if(pTempStationery)
// 				m_rgpStationery.push_back(pTempStationery);
// 		}	


		//load
		int length = 0;
		char buffer[32] = {0x0};
		ar.Read(buffer, sizeof(buffer));

		length = atoi(buffer);
		BYTE * pBytes = new BYTE(length);
		memset(pBytes,0x0,length);

		ar.Read(pBytes,length);
		FromBytes(pBytes, length);


// 		if (pBytes!=NULL)
// 		{
// 			delete []pBytes;
// 			pBytes = NULL;
// 		}
	}
}

Stationery* GroceriesCatalog::FindStationeryByID( int nID )
{
	Stationery* pTmpStationery = NULL;

	for (int i=0; i< (int) m_rgpStationery.size(); ++i)
	{
		Stationery* pStationery = m_rgpStationery.at(i);
		if(pStationery && pStationery->GetID() == nID)
		{
			pTmpStationery = pStationery;
			break;
		}
	}

	return pTmpStationery;
}

bool GroceriesCatalog::isIdExist( int nID )
{
	int times = 0;
	for (int i=0; i< (int) m_rgpStationery.size(); ++i)
	{
		Stationery* pStationery = m_rgpStationery.at(i);
		if(pStationery && pStationery->GetID() == nID)
		{
			times++;
		}
	}
	return (times>=1 ? true : false);
}
/*
bool GroceriesCatalog::AddStationery( Stationery* stationery)
{
	if (!stationery)
		return false;

	bool bExist = false;
	std::vector<Stationery*>::iterator iter = m_rgpStationery.begin();
	for (; iter != m_rgpStationery.end(); ++iter)
	{
		if ((*iter)->GetID() == stationery->GetID())
		{
			bExist = true;
			break;
		}
	}

	if (!bExist)
	{
		m_rgpStationery.push_back(stationery);
	}
	return true;
}
*/

GroceriesCatalog::GroceriesCatalog(BYTE* pBytes,int iLength)
{
	FromBytes(pBytes,iLength);
}

void GroceriesCatalog::FromBytes(BYTE* pBytes,int iLength)
{
	int iCurSize = 0 ;
	BYTE* pCurBytes = pBytes;

	string strbuf((char*)pBytes,iLength),strsecond("");
	size_t pos_start = pCurBytes - pBytes;
	size_t pos_tail = strbuf.find('\0',pos_start);
	if (string::npos!=pos_tail)
	{
		strsecond = strbuf.substr(pos_start,pos_tail);
		m_strName =strsecond.c_str();
		pCurBytes += pos_tail-pos_start+1;

		pos_start = pos_tail + 1;
		pos_tail = strbuf.find('\0',pos_start);
		if (string::npos!=pos_tail)
		{
			strsecond = strbuf.substr(pos_start,pos_tail);
			m_strDescription =strsecond.c_str();
			pCurBytes += pos_tail-pos_start+1;

			pos_start = pos_tail + 1;
		}
	}

	for (vector<GroceriesGroup*>::iterator it = m_rgpChildren.begin(); it != m_rgpChildren.end();++it)
	{
		if ((*it))
		{
			(*it)->FromBytes(pCurBytes,iLength-(pCurBytes-pBytes));
		}
	}

	for (vector<Stationery*>::iterator itsecond = m_rgpStationery.begin(); itsecond != m_rgpStationery.end();++itsecond)
	{
		if ((*itsecond))
		{
			(*itsecond)->FromBytes(pCurBytes,iLength-(pCurBytes-pBytes));
		}
	}


	m_bFromBytes = true;

	//ASSERT((pCurBytes-pBytes)==iLength);
}

BYTE* GroceriesCatalog::GetBytes(int& iLength)
{
	int iTotalSize = m_strName.GetLength()+m_strDescription.GetLength()+4*sizeof('\0')+sizeof(void*);

	BYTE* pBytes = new BYTE[iTotalSize];
	memset(pBytes,0x0,iTotalSize);
	BYTE* pCurBytes = pBytes;

	m_strName +=L"\0";
	int iCurSize = m_strName.GetLength() + 1;
	memcpy(pCurBytes,m_strName.operator LPCTSTR(),iCurSize);
	pCurBytes += iCurSize;

	m_strDescription +=L"\0";
	iCurSize = m_strDescription.GetLength() + 1;
	memcpy(pCurBytes,m_strDescription.operator LPCTSTR(),iCurSize);
	pCurBytes += iCurSize;

	iLength = pCurBytes-pBytes;


	for (vector<GroceriesGroup*>::iterator it = m_rgpChildren.begin(); it != m_rgpChildren.end();++it)
	{
		if ((*it))
		{
			int len = 0;
			void * group = (*it)->GetBytes(len);
			iCurSize = sizeof(void*);
			memcpy(pCurBytes,&group,iCurSize); //store the point
			pCurBytes += iCurSize;
			iLength +=len;
		}
	}

	for (vector<Stationery*>::iterator itsecond = m_rgpStationery.begin(); itsecond != m_rgpStationery.end();++itsecond)
	{
		if ((*itsecond))
		{
			int len = 0;
			void * stationery = (*itsecond)->GetBytes(len);
			iCurSize = sizeof(void*);
			memcpy(pCurBytes,&stationery,iCurSize); //store the point
			pCurBytes += iCurSize;
			iLength +=len;
		}
	}

	pCurBytes[0] = L'\0';
	pCurBytes[1] = L'\0';


	//ASSERT((pCurBytes-pBytes)==iTotalSize);
	return pBytes;
}