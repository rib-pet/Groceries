#include "stdafx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#include "..\Groceries\GroceriesGroup.h"
#include "..\Groceries\GroceriesVisitor.h"
#include "..\Groceries\GroceriesItem.h"

#include <list>
#include "..\Groceries\GroceriesCatalog.h"
#include <string>
#include <iostream>
using namespace std;

IMPLEMENT_SERIAL(GroceriesGroup,CObject,1)

GroceriesGroup::GroceriesGroup(void)
{
}

GroceriesGroup::GroceriesGroup( CObject* Parent )
	: m_pParent(Parent)
{

}

 GroceriesGroup::~GroceriesGroup(void)
 {
	
 }

void GroceriesGroup::SetName( const CString& strKey )
{
	m_strName = strKey;
}

CString GroceriesGroup::GetName() const
{
	return m_strName;
}

GroceriesGroup* GroceriesGroup::CreateGroup()
{
	GroceriesGroup* pNewObj = new GroceriesGroup(this);
	if(pNewObj)
	{
		CString strPrefix ;
		strPrefix = GetName();

		int nSize = (int) m_rgpChildren.size();
		CString strKey;
		strKey.Format(_T("%d"), ++nSize);

		strKey = strPrefix + strKey;
		pNewObj->SetName(strKey);

		m_rgpChildren.push_back(pNewObj);
	}
	return pNewObj;
}

void GroceriesGroup::DeleteGroup( const CString& strKey )
{
	std::vector<GroceriesGroup*>::iterator iter = m_rgpChildren.begin();
	for (; iter != m_rgpChildren.end(); ++iter)
	{
		GroceriesGroup* pGroup = *iter;
		if(pGroup && pGroup->GetName().CompareNoCase(strKey) == 0)
		{
			m_rgpChildren.erase(iter);
			break;
		}
	}
}

void GroceriesGroup::Accept( GroceriesVisitor* pVisitor )
{
	if(pVisitor)
		pVisitor->VisitGroceriesGroup(this);
}

void GroceriesGroup::GetChildren( std::list<CObject*>& rgpChildren )
{
	rgpChildren.clear();
	rgpChildren.assign(m_rgpChildren.begin(),m_rgpChildren.end());
}

CObject* GroceriesGroup::GetParentObject()
{
	return m_pParent;
}

void GroceriesGroup::SetParentObject( CObject* pParent )
{
	if(pParent)
	{
		m_pParent = pParent;
	}
}

CString GroceriesGroup::GetDescription()
{
	return m_strDescription;
}

void GroceriesGroup::SetDescription( const CString& strDesc )
{
	m_strDescription = strDesc;
}

GroceriesItem* GroceriesGroup::CreateItem()
{
	GroceriesItem* pNewObj = new GroceriesItem(this);
	if(pNewObj)
	{
		CString strPrefix ;
		strPrefix = GetName();

		int nSize = (int) m_rgpItems.size();
		CString strKey;
		strKey.Format(_T("%d"), ++nSize);

		strKey = strPrefix + strKey;
		pNewObj->SetName(strKey);

		m_rgpItems.push_back(pNewObj);
	}
	return pNewObj;
}

int GroceriesGroup::GetChildrenCount()
{
	return (int) m_rgpChildren.size();
}

GroceriesGroup* GroceriesGroup::GetGroupAt( int nIndex )
{
	GroceriesGroup* pGroup = NULL;

	int nCount = (int)m_rgpChildren.size();

	if(nIndex >= 0 && nIndex < nCount)
	{
		pGroup = m_rgpChildren.at(nIndex);
	}

	return pGroup;
}

void GroceriesGroup::RemoveAllGroups()
{
	for (int i=0; i< (int) m_rgpChildren.size(); ++i)
	{
		GroceriesGroup* pGroup = m_rgpChildren.at(i);
		if(pGroup)
		{
			delete pGroup;
			pGroup = NULL;
		}
	}

	m_rgpChildren.clear();
}

int GroceriesGroup::GetItemCount()
{
	return (int)m_rgpItems.size();
}

GroceriesItem* GroceriesGroup::GetItemAt( int nIndex )
{
	GroceriesItem* pGroceriesItem = NULL;

	int nCount = (int)m_rgpItems.size();

	if(nIndex >= 0 && nIndex < nCount)
	{
		pGroceriesItem = m_rgpItems.at(nIndex);
	}

	return pGroceriesItem;
}

void GroceriesGroup::DeleteItem( const CString& strKey )
{
	std::vector<GroceriesItem*>::iterator iter = m_rgpItems.begin();
	for (; iter != m_rgpItems.end(); ++iter)
	{
		GroceriesItem* pItem = *iter;
		if(pItem && pItem->GetName().CompareNoCase(strKey) == 0)
		{
			m_rgpItems.erase(iter);
			break;
		}
	}
}

void GroceriesGroup::RemoveAllItems()
{
	for (int i=0; i< (int) m_rgpItems.size(); ++i)
	{
		GroceriesItem* pItem  = m_rgpItems.at(i);
		if(pItem)
		{
			pItem->Delete();
		}
	}
}

void GroceriesGroup::Delete()
{
	RemoveAllItems();

	if(m_pParent)
	{
		GroceriesGroup* pParentGrp = dynamic_cast<GroceriesGroup*>(m_pParent);
		GroceriesCatalog* pParentCat = dynamic_cast<GroceriesCatalog*>(m_pParent);

		if(pParentCat)
		{
			pParentCat->Remove(this);
		}
		else if(pParentGrp)
		{
			pParentGrp->Remove(this);
		}
	}
}

void GroceriesGroup::Remove( CObject* pChild )
{
	if(pChild)
	{
		GroceriesGroup* pGrp = dynamic_cast<GroceriesGroup*>(pChild);
		GroceriesItem* pItem = dynamic_cast<GroceriesItem*>(pChild);
		if(pGrp)
		{
			DeleteGroup(pGrp->GetName());

			delete pGrp;
			pGrp = NULL;
		}
		else if(pItem)
		{
			DeleteItem(pItem->GetName());

			delete pItem;
			pItem = NULL;
		}
	}
}

void GroceriesGroup::Serialize(CArchive& ar)
{
	//__super::Serialize(ar);

	if(ar.IsStoring())
	{
// 		ar << m_strName;
// 		ar << m_strDescription;
// 
// 		int nCount = static_cast<int>(m_rgpChildren.size());
// 		ar << nCount;
// 		if(nCount > 0)
// 		{
// 			for(int i=0; i<nCount; ++i)
// 			{
// 				GroceriesGroup* pTempGroup = m_rgpChildren.at(i);
// 				if(pTempGroup)
// 					ar << pTempGroup;
// 			}
// 		}
// 		
// 		nCount = static_cast<int>(m_rgpItems.size());
// 		ar << nCount;
// 		if( nCount > 0)
// 		{
// 			for(int i=0; i<nCount; ++i)
// 			{
// 				GroceriesItem* pTempItem = m_rgpItems.at(i);
// 				if(pTempItem)
// 					ar << pTempItem;
// 			}
// 		}
// 		
// 		if(m_pParent)
// 			ar << m_pParent;

		int length = 0;
		BYTE * pBytes = GetBytes(length);
		char buflen[32]= {0x0};
		sprintf_s(buflen,"%d",length);
		ar.Write(buflen, sizeof(buflen));
		ar.Write(pBytes, length);

	}
	else
	{
// 		ar >> m_strName;
// 		ar >> m_strDescription;
// 
// 		int nCount;
// 		ar >> nCount;
// 
// 		m_rgpChildren.clear();
// 		GroceriesGroup* pTempGroup = NULL;
// 		for(int i=0; i<nCount; ++i)
// 		{
// 			ar >> pTempGroup;
// 			if(pTempGroup)
// 				m_rgpChildren.push_back(pTempGroup);
// 		}
// 
// 		ar >> nCount;
// 		m_rgpItems.clear();
// 		GroceriesItem* pTempItem=NULL;
// 		for(int i=0; i<nCount; ++i)
// 		{
// 			ar >> pTempItem;
// 			if(pTempItem)
// 				m_rgpItems.push_back(pTempItem);
// 		}
// 
// 		ar >> m_pParent;

		int length = 0;
		char buffer[32] = {0x0};
		ar.Read(buffer, sizeof(buffer));

		length = atoi(buffer);
		BYTE * pBytes = new BYTE(length);
		memset(pBytes,0x0,length);

		ar.Read(pBytes,length);
		FromBytes(pBytes, length);
	}
}

GroceriesGroup::GroceriesGroup(BYTE* pBytes,int iLength)
{
	FromBytes(pBytes,iLength);
}

void GroceriesGroup::FromBytes(BYTE* pBytes,int iLength)
{
	int iCurSize = 0 ;
	BYTE* pCurBytes = pBytes;

	string strbuf((char*)pBytes,iLength),strsecond("");
	size_t pos_start = pCurBytes - pBytes;
	size_t pos_tail = strbuf.find('\0',pos_start);
	if (string::npos!=pos_tail)
	{
		strsecond = strbuf.substr(pos_start,pos_tail);
		m_strName =strsecond.c_str();
		pCurBytes += pos_tail-pos_start+1;

		pos_start = pos_tail + 1;
		pos_tail = strbuf.find('\0',pos_start);
		if (string::npos!=pos_tail)
		{
			strsecond = strbuf.substr(pos_start,pos_tail);
			m_strDescription =strsecond.c_str();
			pCurBytes += pos_tail-pos_start+1;

			pos_start = pos_tail + 1;
		}
	}

	for (vector<GroceriesGroup*>::iterator it = m_rgpChildren.begin(); it != m_rgpChildren.end();++it)
	{
		if ((*it))
		{
			(*it)->FromBytes(pCurBytes,iLength-(pCurBytes-pBytes));
		}
	}

	for (vector<GroceriesItem*>::iterator itsecond = m_rgpItems.begin(); itsecond != m_rgpItems.end();++itsecond)
	{
		if ((*itsecond))
		{
			(*itsecond)->FromBytes(pCurBytes,iLength-(pCurBytes-pBytes));
		}
	}


	m_bFromBytes = true;

	//ASSERT((pCurBytes-pBytes)==iLength);
}

BYTE* GroceriesGroup::GetBytes(int& iLength)
{
	int iTotalSize = m_strName.GetLength()+m_strDescription.GetLength()+4*sizeof('\0')+sizeof(void*);

	BYTE* pBytes = new BYTE[iTotalSize];
	memset(pBytes,0x0,iTotalSize);
	BYTE* pCurBytes = pBytes;

	m_strName +=L"\0";
	int iCurSize = m_strName.GetLength() + 1;
	memcpy(pCurBytes,m_strName.operator LPCTSTR(),iCurSize);
	pCurBytes += iCurSize;

	m_strDescription +=L"\0";
	iCurSize = m_strDescription.GetLength() + 1;
	memcpy(pCurBytes,m_strDescription.operator LPCTSTR(),iCurSize);
	pCurBytes += iCurSize;

	iLength = pCurBytes-pBytes;

	for (vector<GroceriesGroup*>::iterator it = m_rgpChildren.begin(); it != m_rgpChildren.end();++it)
	{
		if ((*it))
		{
			int len = 0;
			void * group = (*it)->GetBytes(len);
			iCurSize = sizeof(void*);
			memcpy(pCurBytes,&group,iCurSize); //store the point
			pCurBytes += iCurSize;
			iLength +=len;
		}
	}

	for (vector<GroceriesItem*>::iterator itsecond = m_rgpItems.begin(); itsecond != m_rgpItems.end();++itsecond)
	{
		if ((*itsecond))
		{
			int len = 0;
			void * item = (*itsecond)->GetBytes(len);
			iCurSize = sizeof(void*);
			memcpy(pCurBytes,&item,iCurSize); //store the point
			pCurBytes += iCurSize;
			iLength +=len;
		}
	}

	pCurBytes[0] = L'\0';
	pCurBytes[1] = L'\0';

	//ASSERT((pCurBytes-pBytes)==iTotalSize);
	return pBytes;
}