#include "stdafx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#include "..\Groceries\Stationery.h"
#include <string>
#include "..\Groceries\GroceriesCatalog.h"



#include <iostream>
using namespace std;

IMPLEMENT_SERIAL(Stationery, CObject, 1)

Stationery::Stationery(void)
: m_dUnitPrice(0.0)
, m_dQuantity(1.0)
, m_nID(0)
, m_strDescription(_T(""))
, m_strComment(_T(""))
, m_strName(_T(""))
, m_pParent(NULL)
,m_bFromBytes(false)
{
}

Stationery::Stationery( CObject* pParent )
	: m_pParent(pParent)
	, m_dUnitPrice(0.0)
	, m_dQuantity(1.0)
	, m_nID(0)
	, m_strDescription(_T(""))
	, m_strName(_T(""))
	, m_strComment(_T(""))
	,m_bFromBytes(false)
{

}


Stationery::~Stationery(void)
{
}

UINT Stationery::GetID()
{
	return m_nID;
}

void Stationery::SetID( UINT nID )
{
	m_nID = nID;
}

double Stationery::GetUnitRate()
{
	return m_dUnitPrice;
}

void Stationery::SetUnitRate( double dValue )
{
	m_dUnitPrice = dValue;
}

double Stationery::GetQuantity()
{
	return m_dQuantity;
}

void Stationery::SetQuantity( double dQuantity )
{
	m_dQuantity = dQuantity;
}

double Stationery::GetCost()
{
	return m_dUnitPrice * m_dQuantity;
}

CString Stationery::GetComment()
{
	return m_strComment;
}

void Stationery::SetComment( const CString& strComment )
{
	m_strComment = strComment;
}

CString Stationery::GetName()
{
	/*CString strName;
	strName.Format(_T("%d"), m_nID);
	*/
	return m_strName;
}

void Stationery::SetName( CString strKey )
{
	// m_nID =  _wtoi(strKey);

	m_strName = strKey;
}

void Stationery::Delete()
{
	if(m_pParent)
	{
		GroceriesCatalog* pParentCat = dynamic_cast<GroceriesCatalog*>(m_pParent);
		if(pParentCat)
		{
			pParentCat->Remove(this);
		}
	}
}

CString Stationery::GetDescription()
{
	return m_strDescription;
}

void Stationery::SetDescription( const CString& strDesc )
{
	m_strDescription = strDesc;
}

void Stationery::Serialize(CArchive& ar)
{
	__super::Serialize(ar);
	if( ar.IsStoring() )
	{
// 		ar << m_nID;
// 		ar << m_dUnitPrice;
// 		ar << m_dQuantity;
// 		ar << m_strName;
// 		ar << m_strDescription;
// 		ar << m_strComment;
// 		if(m_pParent)
// 			ar << m_pParent;

		int length = 0;
		BYTE * pBytes = GetBytes(length);
		char buflen[32]= {0x0};
		sprintf_s(buflen,"%d",length);
		ar.Write(buflen, sizeof(buflen));
		ar.Write(pBytes, length);

// 		if (pBytes!=NULL)
// 		{
// 			delete []pBytes;
// 			pBytes = NULL;
// 		}
	}
	else
	{
// 		ar >> m_nID;
// 		ar >> m_dUnitPrice;
// 		ar >> m_dQuantity;
// 		ar >> m_strName;
// 		ar >> m_strDescription;
// 		ar >> m_strComment;
// 		ar >> m_pParent;

		int length = 0;
		char buffer[32] = {0x0};
		ar.Read(buffer, sizeof(buffer));

		length = atoi(buffer);
		BYTE * pBytes = new BYTE(length);
		memset(pBytes,0x0,length);

		ar.Read(pBytes,length);
		FromBytes(pBytes, length);
	}
}

Stationery::Stationery(BYTE* pBytes,int iLength)
{
	FromBytes(pBytes,iLength);
}

void Stationery::FromBytes(BYTE* pBytes,int iLength)
{
	int iCurSize = 0 ;
	BYTE* pCurBytes = pBytes;

	iCurSize = sizeof(UINT);
	memcpy(&m_nID,pCurBytes,iCurSize);
	pCurBytes += iCurSize;

	iCurSize = sizeof(double);
	memcpy(&m_dUnitPrice,pCurBytes,iCurSize);
	pCurBytes += iCurSize;

	memcpy(&m_dQuantity,pCurBytes,iCurSize);
	pCurBytes += iCurSize;

	string strbuf((char*)pBytes,iLength),strsecond("");
	size_t pos_start = pCurBytes - pBytes;
	size_t pos_tail = strbuf.find('\0',pos_start);
	if (string::npos!=pos_tail)
	{
		strsecond = strbuf.substr(pos_start,pos_tail);
		m_strName =strsecond.c_str();
		pCurBytes += pos_tail-pos_start+1;

		pos_start = pos_tail + 1;
		pos_tail = strbuf.find('\0',pos_start);
		if (string::npos!=pos_tail)
		{
			strsecond = strbuf.substr(pos_start,pos_tail);
			m_strDescription =strsecond.c_str();
			pCurBytes += pos_tail-pos_start+1;

			pos_start = pos_tail + 1;
			pos_tail = strbuf.find('\0',pos_start);
			if (string::npos!=pos_tail)
			{
				strsecond = strbuf.substr(pos_start,pos_tail);
				m_strComment =strsecond.c_str();
				pCurBytes += pos_tail-pos_start+1;
			}

		}
	}


	m_bFromBytes = true;

	//ASSERT((pCurBytes-pBytes)==iLength);
}

BYTE* Stationery::GetBytes(int& iLength)
{
	int iTotalSize = sizeof(UINT)+sizeof(double)*2+m_strName.GetLength()+m_strDescription.GetLength()+m_strComment.GetLength()+4*sizeof('\0');
	BYTE* pBytes = new BYTE[iTotalSize];
	memset(pBytes,0x0,iTotalSize);
	BYTE* pCurBytes = pBytes;

	int iCurSize = sizeof(int);
	memcpy(pCurBytes,&m_nID,iCurSize);
	pCurBytes += iCurSize;

	iCurSize = sizeof(double);
	memcpy(pCurBytes,&m_dUnitPrice,iCurSize);
	pCurBytes += iCurSize;

	memcpy(pCurBytes,&m_dQuantity,iCurSize);
	pCurBytes += iCurSize;

	m_strName +=L'\0';
	iCurSize = m_strName.GetLength() + 1;
	memcpy(pCurBytes,m_strName.operator LPCTSTR(),iCurSize);
	pCurBytes += iCurSize;

	m_strDescription +=L'\0';
	iCurSize = m_strDescription.GetLength() + 1;
	memcpy(pCurBytes,m_strDescription.operator LPCTSTR(),iCurSize);
	pCurBytes += iCurSize;

	m_strComment +=L"\0\0";
	iCurSize = m_strComment.GetLength() + 2;
	memcpy(pCurBytes,m_strComment.operator LPCTSTR(),iCurSize);
	pCurBytes += iCurSize;
	iLength = pCurBytes-pBytes;

	//ASSERT((pCurBytes-pBytes)==iTotalSize);
	return pBytes;
}