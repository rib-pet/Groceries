#include "stdafx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#include "..\Groceries\Stuff.h"
#include "..\Groceries\GroceriesVisitor.h"
#include "..\Groceries\Stationery.h"

#include <string>
#include <iostream>
using namespace std;

IMPLEMENT_SERIAL(Stuff,CObject, 1)

Stuff::Stuff(void)
	: m_pStationery(NULL)
	, m_dQuantity(1.0)
	,m_bFromBytes(false)
{
}

Stuff::~Stuff(void)
{
	if (m_bFromBytes&&m_pStationery!=NULL)
	{
		delete m_pStationery;
		m_pStationery = NULL;
	}
}

void Stuff::Accept( GroceriesVisitor* pVisitor )
{
	pVisitor->VisitStuff(this);
}

CString Stuff::GetName()
{
	return m_strName;
}

void Stuff::Delete()
{
	if(m_pStationery != NULL)
	{
		delete m_pStationery;
		m_pStationery = NULL;
	}
}

Stationery* Stuff::GetStationery()
{
	return m_pStationery;
}

void Stuff::SetStationery( Stationery* pStationery)
{
	if(m_pStationery != pStationery)
	{
		m_pStationery = pStationery;
	}
}

CString Stuff::GetDescription()
{
	return m_strDesription;
}

void Stuff::SetName( const CString& strName )
{
	if(strName != m_strName)
	{
		m_strName = strName;
	}
}

void Stuff::SetQuantity( double dQuantity )
{
	m_dQuantity = dQuantity;
}

double Stuff::GetQuantity()
{
	return m_dQuantity;
}

void Stuff::Serialize(CArchive& ar)
{
	__super::Serialize(ar);
	if(ar.IsStoring())
	{
// 		ar << m_strName;
// 		ar << m_strDesription;
// 		if(m_pParent)
// 			ar << m_pParent;
// 		if(m_pStationery)
// 			ar << m_pStationery;
// 		ar << m_dQuantity;

		int length = 0;
		BYTE * pBytes = GetBytes(length);
		char buflen[32]= {0x0};
		sprintf_s(buflen,"%d",length);
		ar.Write(buflen, sizeof(buflen));
		ar.Write(pBytes, length);

// 		if (pBytes!=NULL)
// 		{
// 			delete []pBytes;
// 			pBytes = NULL;
// 		}
	}
	else
	{
// 		ar >> m_strName;
// 		ar >> m_strDesription;
// 		ar >> m_pParent;
// 		ar >> m_pStationery;
// 		ar >> m_dQuantity;

		int length = 0;
		char buffer[32] = {0x0};
		ar.Read(buffer, sizeof(buffer));

		length = atoi(buffer);
		BYTE * pBytes = new BYTE(length);
		memset(pBytes,0x0,length);

		ar.Read(pBytes,length);
		FromBytes(pBytes, length);
	}
}

void Stuff::SetDescription( CString strDesription )
{
	m_strDesription = strDesription;
}

CObject* Stuff::GetParent()
{
	return m_pParent;
}

Stuff::Stuff(BYTE* pBytes,int iLength)
{
	FromBytes(pBytes,iLength);
}

void Stuff::FromBytes(BYTE* pBytes,int iLength)
{
	int iCurSize = 0 ;
	BYTE* pCurBytes = pBytes;

	iCurSize = sizeof(double);
	memcpy(&m_dQuantity,pCurBytes,iCurSize);
	pCurBytes += iCurSize;

	string strbuf((char*)pBytes,iLength),strsecond("");
	size_t pos_start = pCurBytes - pBytes;
	size_t pos_tail = strbuf.find('\0',pos_start);
	if (string::npos!=pos_tail)
	{
		strsecond = strbuf.substr(pos_start,pos_tail);
		m_strName =strsecond.c_str();
		pCurBytes += pos_tail-pos_start+1;

		pos_start = pos_tail + 1;
		pos_tail = strbuf.find('\0',pos_start);
		if (string::npos!=pos_tail)
		{
			strsecond = strbuf.substr(pos_start,pos_tail);
			m_strDesription =strsecond.c_str();
			pCurBytes += pos_tail-pos_start+1;
			pos_start = pos_tail + 1;
		}
	}

	if (m_pStationery)
	{
		m_pStationery->FromBytes(pCurBytes,iLength-(pCurBytes-pBytes));
	}

	m_bFromBytes = true;

	//ASSERT((pCurBytes-pBytes)==iLength);
}

BYTE* Stuff::GetBytes(int& iLength)
{
	int iTotalSize = 0;
	iTotalSize = sizeof(double)+m_strName.GetLength()+m_strDesription.GetLength()+4*sizeof('\0')+sizeof(void*);


	BYTE* pBytes = new BYTE[iTotalSize];
	memset(pBytes,0x0,iTotalSize);
	BYTE* pCurBytes = pBytes;

	int iCurSize = sizeof(double);
	memcpy(pCurBytes,&m_dQuantity,iCurSize);
	pCurBytes += iCurSize;

	m_strName +=L'\0';
	iCurSize = m_strName.GetLength() + 1;
	memcpy(pCurBytes,(LPCTSTR)m_strName,iCurSize);
	pCurBytes += iCurSize;

	m_strDesription +=L"\0";
	iCurSize = m_strDesription.GetLength() + 1;
	memcpy(pCurBytes,(LPCTSTR)m_strDesription,iCurSize);
	pCurBytes += iCurSize;

	iLength = pCurBytes-pBytes;

	if (m_pStationery)
	{
		int len = 0;
		void * ptrstationery = m_pStationery->GetBytes(len);
		iCurSize = sizeof(void*);
		memcpy(pCurBytes,&ptrstationery,iCurSize); //store the point
		pCurBytes += iCurSize;
		iLength +=len;
		pCurBytes[0] = L'\0';
		pCurBytes[1] = L'\0';
	}

	//ASSERT((pCurBytes-pBytes)==iTotalSize);
	return pBytes;
}
