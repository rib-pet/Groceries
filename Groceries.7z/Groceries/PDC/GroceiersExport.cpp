#include "stdafx.h"
#include "..\Groceries\GroceiersExport.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


using namespace System;
using namespace System::Xml;

class GroceriesExportWrapper::GroceriesExport
{
public:
	GroceriesExport();
	~GroceriesExport();

	gcroot<XmlWriter^> m_pXmlWriter;
};

GroceriesExportWrapper::GroceriesExport::GroceriesExport()
	: m_pXmlWriter(nullptr)
{
	
}

GroceriesExportWrapper::GroceriesExport::~GroceriesExport()
{
	if(m_pXmlWriter)
	{
		delete m_pXmlWriter;
		m_pXmlWriter = nullptr;
	}
}


GroceriesExportWrapper::GroceriesExportWrapper()
{

}

GroceriesExportWrapper::~GroceriesExportWrapper()
{

}
