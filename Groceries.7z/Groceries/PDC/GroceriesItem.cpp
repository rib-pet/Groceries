#include "stdafx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#include "..\Groceries/GroceriesItem.h"
#include "../Groceries/Stuff.h"
#include "../Groceries/GroceriesVisitor.h"
#include "../Groceries/Stationery.h"


#include <string>
#include <iostream>
using namespace std;


IMPLEMENT_SERIAL(GroceriesItem, CObject, 1)

GroceriesItem::GroceriesItem(void)
{
}

GroceriesItem::GroceriesItem( CObject* pParent )
	:m_pParent(pParent)

{

}


GroceriesItem::~GroceriesItem(void)
{
}

int GroceriesItem::GetAllStuffs( std::vector<Stuff*>& rgpStuffs )
{
	rgpStuffs.clear();

	rgpStuffs.assign(m_rgpStuffs.begin(), m_rgpStuffs.end());

	return (int) rgpStuffs.size();
}

void GroceriesItem::Delete()
{
	RemoveAllStuffs();

	if(m_pParent)
	{
		GroceriesGroup* pParentGrp = dynamic_cast<GroceriesGroup*>(m_pParent);
		if(pParentGrp)
		{
			pParentGrp->Remove(this);
		}
	}
}

void GroceriesItem::Remove( CObject* pChild )
{
	if(pChild)
	{
		Stuff* pStuff = dynamic_cast<Stuff*>(pChild);
		if(pStuff)
		{
			DeleteStuff(pStuff->GetName());

			delete pStuff;
			pStuff = NULL;
		}
	}
}

void GroceriesItem::RemoveAllStuffs()
{
	for (int i=0; i< (int) m_rgpStuffs.size(); ++i)
	{
		Stuff* pStuff  = m_rgpStuffs.at(i);
		if(pStuff)
		{
			pStuff->Delete();
		}
	}
}

void GroceriesItem::DeleteStuff( const CString& strName )
{
	std::vector<Stuff*>::iterator iter = m_rgpStuffs.begin();
	for (; iter != m_rgpStuffs.end(); ++iter)
	{
		Stuff* pStuff = *iter;
		if(pStuff && pStuff->GetName().CompareNoCase(strName) == 0)
		{
			m_rgpStuffs.erase(iter);
			break;
		}
	}
}

void GroceriesItem::SetName( const CString& strKey )
{
	if (strKey.CompareNoCase(m_strName) != 0)
	{
		m_strName = strKey;
	}
}

CString GroceriesItem::GetName()
{
	return m_strName;
}

void GroceriesItem::SetDescription( const CString& strDesc )
{
	if (strDesc.CompareNoCase(m_strDescription) != 0)
	{
		m_strDescription = strDesc;
	}
}

CString GroceriesItem::GetDescription()
{
	return m_strDescription;
}

void GroceriesItem::Accept( GroceriesVisitor* pVisitor )
{
	if(pVisitor)
		pVisitor->VisitGroceriesItem(this);
}

Stuff* GroceriesItem::CreateStuff()
{
	Stuff* pNewObj =  new Stuff();
	if(pNewObj)
	{
		CString strPrefix ;
		strPrefix = GetName();

		int nSize = (int) m_rgpStuffs.size();
		CString strKey;
		strKey.Format(_T("%d"), ++nSize);

		strKey = strPrefix + strKey;
		pNewObj->SetName(strKey);

		m_rgpStuffs.push_back(pNewObj);
	}
	return pNewObj;
}

void GroceriesItem::Serialize(CArchive& ar)
{
	__super::Serialize(ar);
	if(ar.IsStoring())
	{
// 		int nCount = (int)m_rgpStuffs.size();
// 		ar << nCount;
// 		if(nCount > 0)
// 		{
// 			for(int i=0; i<nCount; ++i)
// 			{
// 				Stuff* pTempStuff = m_rgpStuffs.at(i);
// 				ar << pTempStuff;
// 			}
// 		}
// 		
// 		if(m_pParent)
// 			ar << m_pParent;
// 		ar << m_strName;
// 		ar << m_strDescription;

		int length = 0;
		BYTE * pBytes = GetBytes(length);
		char buflen[32]= {0x0};
		sprintf_s(buflen,"%d",length);
		ar.Write(buflen, sizeof(buflen));
		ar.Write(pBytes, length);

// 		if (pBytes!=NULL)
// 		{
// 			delete []pBytes;
// 			pBytes = NULL;
// 		}
	}
	else
	{
// 		int nCount;
// 		ar >> nCount;
// 		Stuff* pTempStuff = NULL;
// 		for(int i=0; i<nCount; ++i)
// 		{
// 			ar >> pTempStuff;
// 			if(pTempStuff)
// 				m_rgpStuffs.push_back(pTempStuff);
// 		}
// 		
// 		ar >> m_pParent;
// 		ar >> m_strName;
// 		ar >> m_strDescription;

		int length = 0;
		char buffer[32] = {0x0};
		ar.Read(buffer, sizeof(buffer));

		length = atoi(buffer);
		BYTE * pBytes = new BYTE(length);
		memset(pBytes,0x0,length);

		ar.Read(pBytes,length);
		FromBytes(pBytes, length);
	}
}

bool GroceriesItem::IsUnique( Stationery* pStationery )
{
	bool bUnique = true;

	if(!pStationery)
		return false;

	int nTime = 0;
	int nCount = (int)m_rgpStuffs.size();
	for (int i = 0; i < nCount; ++i)
	{
		Stuff* pStuff = m_rgpStuffs.at(i);
		if(pStuff && pStuff->GetStationery() == pStationery)
		{
			++nTime;

			if(nTime > 1)
			{
				bUnique = false;
				break;
			}
		}
	}

	return bUnique;
}

GroceriesItem::GroceriesItem(BYTE* pBytes,int iLength)
{
	FromBytes(pBytes,iLength);
}

void GroceriesItem::FromBytes(BYTE* pBytes,int iLength)
{
	BYTE* pCurBytes = pBytes;

	string strbuf((char*)pBytes,iLength),strsecond("");
	size_t pos_start = pCurBytes - pBytes;
	size_t pos_tail = strbuf.find('\0',pos_start);
	if (string::npos!=pos_tail)
	{
		strsecond = strbuf.substr(pos_start,pos_tail);
		m_strName =strsecond.c_str();
		pCurBytes += pos_tail-pos_start+1;

		pos_start = pos_tail + 1;
		pos_tail = strbuf.find('\0',pos_start);
		if (string::npos!=pos_tail)
		{
			strsecond = strbuf.substr(pos_start,pos_tail);
			m_strDescription =strsecond.c_str();
			pCurBytes += pos_tail-pos_start+1;
			pos_start = pos_tail + 1;
		}
	}

	for (vector<Stuff*>::iterator it = m_rgpStuffs.begin(); it != m_rgpStuffs.end();++it)
	{
		if ((*it))
		{
			(*it)->FromBytes(pCurBytes,iLength-(pCurBytes-pBytes));
		}

	}


	m_bFromBytes = true;

	//ASSERT((pCurBytes-pBytes)==iLength);
}

BYTE* GroceriesItem::GetBytes(int& iLength)
{
	int iTotalSize = m_strName.GetLength()+m_strDescription.GetLength()+4*sizeof('\0')+sizeof(void*);


	BYTE* pBytes = new BYTE[iTotalSize];
	memset(pBytes,0x0,iTotalSize);
	BYTE* pCurBytes = pBytes;

	int iCurSize = 0;


	m_strName +=L'\0';
	iCurSize = m_strName.GetLength() + 1;
	memcpy(pCurBytes,m_strName.operator LPCTSTR(),iCurSize);
	pCurBytes += iCurSize;

	m_strDescription +=L"\0";
	iCurSize = m_strDescription.GetLength() + 1;
	memcpy(pCurBytes,m_strDescription.operator LPCTSTR(),iCurSize);
	pCurBytes += iCurSize;

	iLength = pCurBytes-pBytes;

	for (vector<Stuff*>::iterator it = m_rgpStuffs.begin(); it != m_rgpStuffs.end();++it)
	{
		if ((*it))
		{
			int len = 0;
			void * stuff = (*it)->GetBytes(len);
			iCurSize = sizeof(void*);
			memcpy(pCurBytes,&stuff,iCurSize); //store the point
			pCurBytes += iCurSize;
			iLength +=len;
		}
	}

	pCurBytes[0] = L'\0';
	pCurBytes[1] = L'\0';

	//ASSERT((pCurBytes-pBytes)==iTotalSize);
	return pBytes;
}
