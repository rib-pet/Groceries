#include "stdafx.h"
#include "..\Groceries\GroceriesVisitor.h"
#include "..\Groceries\GroceriesCatalog.h"
#include "..\Groceries\GroceriesGroup.h"
#include "..\Groceries\GroceriesItem.h"
#include "..\Groceries\Stuff.h"


GroceriesVisitor::GroceriesVisitor(void)
{
}

GroceriesVisitor::~GroceriesVisitor(void)
{
}

void GroceriesVisitor::VisitGroceriesCatalog( GroceriesCatalog* pCatalog )
{
	if(pCatalog)
	{
		std::list<CObject*> rgpChildren;
		pCatalog->GetChildren(rgpChildren);
		
		std::list<CObject*>::iterator it = rgpChildren.begin();
		for( it = rgpChildren.begin(); it != rgpChildren.end(); it++ )
		{
			GroceriesGroup* pChild = dynamic_cast<GroceriesGroup* >(*it);
			pChild->Accept( this );
		}
	}
}

void GroceriesVisitor::VisitGroceriesGroup( GroceriesGroup* pGroceriesGroup )
{
	if(pGroceriesGroup)
	{
		std::list<CObject*> rgpChildren;
		pGroceriesGroup->GetChildren(rgpChildren);

		std::list<CObject*>::iterator it = rgpChildren.begin();
		for( it = rgpChildren.begin(); it != rgpChildren.end(); it++ )
		{
			GroceriesGroup* pChild = dynamic_cast<GroceriesGroup* >(*it);
			pChild->Accept( this );
		}
	}
}

void GroceriesVisitor::VisitGroceriesItem( GroceriesItem* pGroceriesItem )
{
	if(pGroceriesItem)
	{
// 		std::list<CObject*> rgpChildren;
// 		pGroceriesItem->GetChildren(rgpChildren);
// 
// 		std::list<CObject*>::iterator it = rgpChildren.begin();
// 		for( it = rgpChildren.begin(); it != rgpChildren.end(); it++ )
// 		{
// 			GroceriesGroup* pChild = dynamic_cast<GroceriesGroup* >(*it);
// 			pChild->Accept( this );
// 		}
		
		std::vector<Stuff*> rgpStuffs;
		int nCount = pGroceriesItem->GetAllStuffs(rgpStuffs);

		for (std::vector<Stuff*>::iterator it = rgpStuffs.begin(); it != rgpStuffs.end(); ++it)
		{
			Stuff* pStuff = *it;
			if(pStuff)
			{
				pStuff->Accept(this);
			}
		}
	}
}

void GroceriesVisitor::VisitStuff( Stuff* pStuff )
{
	
}
